<!DOCTYPE html>
<html lang="pt-br">

<head>
    <title> PLANO DE ESTÁGIO (previsto na Lei de Estágio 11.788/08) </title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="{{ public_path('/css/bootstrap.min.css') }}">
</head>

<body>
    <img src="{{ public_path('/images/logo-rhmais.png') }}" style="margin-left:270px; width:20%;">
    <h5 class="text-center"><strong> PLANO DE ESTÁGIO (previsto na Lei de Estágio 11.788/08) </strong></h5>
@foreach ($estagio as $plan)

    <p class="text-center">
         Estagiário(a): {{$plan->estagiaria}}LAURA BEATRIZ CARDOSO DE CARVALHO
        CPF: 135.633.236-66
        Matrículado(a) no : 04o Período
        do nível: NS - NÍVEL SUPERIOR
        do curso de : CIENCIAS CONTABEIS - Matrícula no : D2961A-5
        Setor : ADMINISTRATIVO - Atividade : ORGANIZAÇÃO DE CONTRATOS, ENVIO DE DOCUMENTOS AOS CLIENTES, BAIXA NOS
        CONTRATOS
        PELO SISTEMA.
        Supervisor(a) do estágio: ELAINE AP MENEGUSSI CATANIO - SUPERIOR EM ADMINISTRAÇÃO - SUPERVISORA DE ESTÁGIO -
        VENDAS@RPPROMOTORA.COM.BR - (16)3441-9495 -
    </p>
    <hr>
    <div>
        <p> <strong> parte Concedente : </strong> <span class="text-danger"> BORGES & VENANCIO LTDA - ME </span>
            <strong> CNPJ: </strong> <span class="text-danger"> 22.514.472/0001-03 / RP PROMOTORA </span> </p>
    </div>
    <hr>
    <div>
        <p> <strong> Instituição de Ensino: </strong> <span class="text-danger"> ASSUPERO - ENSINO SUPERIOR LTDA </span>
            <strong> CNPJ: </strong> <span class="text-danger"> 06.099.229/0052-51 / UNIP RIBEIRÃO PRETO </span> </p>
    </div>
    <hr>
    <div>
        <p> <strong> Termo de Compromisso Estágio no: </strong> <span class="text-danger"> 20181124012256 </span>
            <strong> Vigência do Estágio: </strong> <span class="text-danger"> 10/09/2018 a 10/09/2020 </span> </p>
    </div>
    <hr>
    <div>
        <p> <strong> Plano de Atividades : </strong> </p>
    </div>
    <hr>
    <div>
        <p> <strong> Observação : </strong> </p>
    </div>
    <hr>
    <div>
        <p> <strong> RIBEIRÃO PRETO , 05/08/2019 </strong> </p>
    </div>
    <hr>

    <p> </p>
    <div style="height:50px;"></div>

    <p class="pull-left">__________________________________ <br>
        KOSTER E KOSTER CONSULTORIA EM RH LTDA <br><br>
        <span>(assinatura e carimbo) </span>
    </p>
    <p class="pull-left" style="margin-left:30px;">
        _________________________________ <br>
        LAURA BEATRIZ CARDOSO DE CARVALHO <br><br>
        <span>(assinatura do(a) estagiário) </span>
    </p>
    <br><br><br><br><br>
    <div style="margin-top:20px;"></div>
    <br>
    <p class="pull-left">
        <br><br><br>
        _________________________________ <br>
        BORGES & VENANCIO LTDA - ME <br><br>
        <span>(assinatura e carimbo) </span>
    </p>
    <p class="pull-left" style="margin-left:80px;">
        _________________________________ <br>
        ELAINE AP MENEGUSSI CATANIO <br><br>
        <span> (assinatura e carimbo)-Supervisor </span>
    </p>

    <p style="margin-top:140px;">
        _________________________________ <br>
        ASSUPERO - ENSINO SUPERIOR LTDA<br><br>
        <span> (assinatura e carimbo) </span>
    </p>
    <p class="pull-right" style="margin-right:100px; margin-top:-90px;">
        _________________________________ <br>
        CAROLINA MACAGNANI DOS SANTOS <br><br>
        <span> (assinatura e carimbo)-Supervisor </span>
    </p>
@endforeach

</body>

</html>
