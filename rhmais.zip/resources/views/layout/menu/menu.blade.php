<div class="navbar nav_title" style="border: 0;">
    <a href="/home"><img src="{{asset('images/logo.png')}}" alt="" style="width:120px; margin:10px auto; display:block;"></a>
</div>
<div class="clearfix"></div>
<!-- menu profile quick info -->
<!-- /menu profile quick info -->
