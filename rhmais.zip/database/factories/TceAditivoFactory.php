<?php

use Faker\Generator as Faker;

$factory->define(App\TceAditivo::class, function (Faker $faker) {
    return [
        //
    ];
});
