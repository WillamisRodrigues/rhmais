<?php

use Faker\Generator as Faker;

$factory->define(App\Endereco::class, function (Faker $faker) {
    return [
        //
    ];
});
