<?php

use Faker\Generator as Faker;

$factory->define(App\Horario::class, function (Faker $faker) {
    return [
        //
    ];
});
