<?php

use Faker\Generator as Faker;

$factory->define(App\Recesso::class, function (Faker $faker) {
    return [
        //
    ];
});
