<?php

use Faker\Generator as Faker;

$factory->define(App\Atividade::class, function (Faker $faker) {
    return [
        //
    ];
});
