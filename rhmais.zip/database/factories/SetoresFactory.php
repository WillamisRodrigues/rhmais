<?php

use Faker\Generator as Faker;

$factory->define(App\Setores::class, function (Faker $faker) {
    return [
        //
    ];
});
