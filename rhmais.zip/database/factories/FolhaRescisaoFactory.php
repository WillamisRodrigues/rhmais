<?php

use Faker\Generator as Faker;

$factory->define(App\FolhaRescisao::class, function (Faker $faker) {
    return [
        //
    ];
});
