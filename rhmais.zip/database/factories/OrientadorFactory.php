<?php

use Faker\Generator as Faker;

$factory->define(App\Orientador::class, function (Faker $faker) {
    return [
        //
    ];
});
