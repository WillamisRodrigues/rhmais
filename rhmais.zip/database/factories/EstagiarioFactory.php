<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Estagiario;
use Faker\Generator as Faker;

$factory->define(Estagiario::class, function (Faker $faker) {
    return [
        //
    ];
});
