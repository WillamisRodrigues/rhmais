<?php

use Faker\Generator as Faker;

$factory->define(App\Cidade::class, function (Faker $faker) {
    return [
        //
    ];
});
