<?php

use Faker\Generator as Faker;

$factory->define(App\Motivo::class, function (Faker $faker) {
    return [
        //
    ];
});
