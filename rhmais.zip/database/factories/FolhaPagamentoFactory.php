<?php

use Faker\Generator as Faker;

$factory->define(App\FolhaPagamento::class, function (Faker $faker) {
    return [
        //
    ];
});
