<?php

use Faker\Generator as Faker;

$factory->define(App\Avaliacao::class, function (Faker $faker) {
    return [
        //
    ];
});
