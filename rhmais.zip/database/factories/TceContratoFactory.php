<?php

use Faker\Generator as Faker;

$factory->define(App\TceContrato::class, function (Faker $faker) {
    return [
        //
    ];
});
