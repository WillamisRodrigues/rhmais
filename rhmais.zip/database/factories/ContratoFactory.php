<?php

use Faker\Generator as Faker;

$factory->define(App\Contrato::class, function (Faker $faker) {
    return [
        //
    ];
});
