<?php

use Faker\Generator as Faker;

$factory->define(App\Motivos::class, function (Faker $faker) {
    return [
        //
    ];
});
