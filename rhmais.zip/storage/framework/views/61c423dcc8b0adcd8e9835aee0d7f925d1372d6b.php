<!DOCTYPE html>

<html>
<head>
    <title>Laravel Dependent Dropdown</title>
</head>
<body>
<img src="<?php echo e(url("images/logo.png")); ?>">
</body>
</html>