<?php $__env->startSection('titulo','Informe de Faturamento | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->

        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <!-- <a href="<?php echo e(url('estagiario/exportar')); ?>">Print  PDF</a> -->
                <div class="clearfix"></div>

                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <form action="/processar_financeiro" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-2">
                                <label for="">Agente:</label>
                                <select name="" class="form-control">
                                    <option> KOSTER E KOSTER CONSULTORIA EM RH LTDA - RH MAIS TALENTOS</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label for="">Unidade:</label>
                                <select name="unidade" class="form-control">
                                    <option> Nome da Unidade</option>
                                     <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unidade->nome_fantasia); ?>"> <?php echo e($unidade->nome_fantasia); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label for="">Período:</label>
                                <select name="referencia" class="form-control">
                                    <option value=""> Periodo Ano</option>
                                    <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($periodo->referencia); ?>"> <?php echo e($periodo->referencia); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <br>
                                <button class="btn btn-primary">Processar</button>
                                <button class="btn btn-primary">Rel. Agente</button>
                                <button class="btn btn-primary">L. Relação</button>
                            </div>
                        </form>
                        <br>
                        <div class="x_panel">
                            <div class="x_title">

                                <h2>Informe de Faturamento</h2>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <table class="table table-striped list  table-bordered" style="zoom:0.8;">
                                    <thead>
                                        <tr>
                                            <th>Unidade
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>Referência
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Dia Vcto
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            
                                            <th>C.Unitario
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Q.Resc.
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Q.Ativos
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>V.Calculado
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Fechado
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Opções
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $contratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>  <?php
                                                foreach ($empresas as $empresa) {
                                                if ($empresa->id == $contrato->empresa_id) {
                                                echo $empresa->nome_fantasia;
                                                }
                                                }
                                                ?>
                                            </td>
                                            <td><?php echo e($contrato->referencia); ?></td>
                                            <td><?php echo e($contrato->data_boleto); ?></td>
                                            
                                            <td><?php
                                                foreach ($empresas as $empresa) {
                                                if ($empresa->id == $contrato->empresa_id) {
                                                echo "R$ ".number_format($empresa->custo_unitario, 2, ',', '.');;
                                                }
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php echo e($qRescisao); ?>

                                            </td>
                                            <td>
                                                <?php echo e($qAtivos); ?>

                                            </td>
                                            <td><?php echo e("R$ ".number_format($contrato->total_custo, 2)); ?></td>
                                            <td>
                                                <?php if($contrato->situacao != 1): ?>
                                                Aberto
                                                <?php else: ?>
                                                Fechado
                                                <?php endif; ?>
                                            </td>
                                             <td>
                                                 <a href="<?php echo e(route('financeiro.fechar', [$contrato->id])); ?>"
                                                    class="btn btn-primary" title="Marcar contrato como fechado"> <i
                                                        class="fa fa-star"></i> </a>
                                            </td>
                                            <td>VALOR <BR> SOMA <BR> % <BR> CONTRATO<BR> ESTAGIARIO
                                            </td>
                                            <td><a href="<?php echo e(route('financeiro.infos', [$contrato->id])); ?>"
                                                    class="btn btn-primary" title="Detalhes"><i class="fa fa-bars"></i></a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- /page content -->

    <!-- footer content -->
    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /footer content -->
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>