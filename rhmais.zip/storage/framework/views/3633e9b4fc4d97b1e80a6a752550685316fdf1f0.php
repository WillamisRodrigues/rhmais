<?php $__env->startSection('titulo','Editar empresass | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- /menu profile quick info -->

                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- /sidebar menu -->
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="clearfix"></div>

            <div class="row">

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>Cadastro de Empresas</h2>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <?php echo Form::open(['route' => ['empresa.update', $empresa->id], 'method' => 'patch']); ?>


                            <!-- SmartWizard html -->
                            <div id="smartwizard">
                                <ul>
                                    <li><a href="#step-1">Passo 1<br /><small>Cadastro Empresa</small></a></li>
                                    <li><a href="#step-2">Passo 2<br /><small>Cadastro de Endereço</small></a></li>
                                </ul>

                                <div>
                                    <div id="step-1">
                                        <br>
                                        <div id="form-step-0" role="form" data-toggle="validator">
                                            <div class="row" style="width:960px; margin: 0 auto;">
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control cnpj has-feedback-left"
                                                        placeholder="CNPJ / CPF" name="cnpj" value="<?php echo e($empresa->cnpj); ?>">
                                                    <span class="fa fa-bars form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>

                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Razão Social / Nome" name="razao_social"
                                                        value="<?php echo e($empresa->razao_social); ?>">
                                                    <span class="fa fa-bars form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                               <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <select  class="form-control has-feedback-left" name="estado">
                                                        <option selected="<?php echo e($empresa->estado); ?>"><?php echo e($empresa->estado); ?></option>
                                                        <option value="Acre">Acre</option>
                                                        <option value="Alagoas">Alagoas</option>
                                                        <option value="Amapá">Amapá</option>
                                                        <option value="Amazonas">Amazonas</option>
                                                        <option value="Bahia">Bahia</option>
                                                        <option value="Ceará">Ceará</option>
                                                        <option value="Distrito Federal">Distrito Federal</option>
                                                        <option value="Espírito Santo">Espírito Santo</option>
                                                        <option value="Goiás">Goiás</option>
                                                        <option value="Maranhão">Maranhão</option>
                                                        <option value="Mato Grosso">Mato Grosso</option>
                                                        <option value="Mato Grosso do Sul">Mato Grosso do Sul</option>
                                                        <option value="Minas Gerais">Minas Gerais</option>
                                                        <option value="Pará">Pará</option>
                                                        <option value="Paraíba">Paraíba</option>
                                                        <option value="Paraná">Paraná</option>
                                                        <option value="Pernambuco">Pernambuco</option>
                                                        <option value="Piauí">Piauí</option>
                                                        <option value="Rio de Janeiro">Rio de Janeiro</option>
                                                        <option value="Rio Grande do Norte">Rio Grande do Norte</option>
                                                        <option value="Rio Grande do Sul">Rio Grande do Sul</option>
                                                        <option value="Rondônia">Rondônia</option>
                                                        <option value="Roraima">Roraima</option>
                                                        <option value="Santa Catarina">Santa Catarina</option>
                                                        <option value="São Paulo">São Paulo</option>
                                                        <option value="Sergipe">Sergipe</option>
                                                        <option value="Tocantins">Tocantins</option>
                                                    </select>
                                                    <span class="fa fa-graduation-cap form-control-feedback left" aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left" placeholder="Cidade"
                                                        name="cidade" value="<?php echo e($empresa->cidade); ?>">
                                                    <span class="fa fa-map-marker form-control-feedback left" aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Insc. Estadual/Rg" name="insc_estadual"
                                                        value="<?php echo e($empresa->insc_estadual); ?>">
                                                    <span class="fa fa-bars form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Numero" name="numero" value="<?php echo e($empresa->numero); ?>">
                                                    <span class="fa fa-map-marker form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>

                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Bairro" name="bairro" value="<?php echo e($empresa->bairro); ?>">
                                                    <span class="fa fa-map-marker form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control telefone has-feedback-left"
                                                        placeholder="Telefone" name="telefone"
                                                        value="<?php echo e($empresa->telefone); ?>">
                                                    <span class="fa fa-phone form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="End. Site" name="site_url"
                                                        value="<?php echo e($empresa->site_url); ?>">
                                                    <span class="fa fa-at form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>

                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control telefone has-feedback-left"
                                                        placeholder="Celular cont." name="celular"
                                                        value="<?php echo e($empresa->celular); ?>">
                                                    <span class="fa fa-phone form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Nome Representante" name="nome_rep"
                                                        value="<?php echo e($empresa->nome_rep); ?>">
                                                    <span class="fa fa-user form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>

                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control cpf has-feedback-left"
                                                        placeholder="CPF Representante" name="cpf_rep"
                                                        value="<?php echo e($empresa->cpf_rep); ?>">
                                                    <span class="fa fa-bars form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="email" class="form-control has-feedback-left"
                                                        placeholder="Email Representante" name="email_rep"
                                                        value="<?php echo e($empresa->email_rep); ?>">
                                                    <span class="fa fa-at form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>

                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="KOSTER E KOSTER CONSULTORIA EM RH LTDA - RH MAIS TALENTOS"
                                                        value="KOSTER E KOSTER CONSULTORIA EM RH LTDA - RH MAIS TALENTOS"
                                                        name="agente_integracao">
                                                    <span class="fa fa-user form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Nome Fantasia" name="nome_fantasia"
                                                        value="<?php echo e($empresa->nome_fantasia); ?>">
                                                    <span class="fa fa-home form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>

                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Endereço" name="rua"
                                                        value="<?php echo e($empresa->rua); ?>">
                                                    <span class="fa fa-map-marker form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Complemento" name="complemento"
                                                        value="<?php echo e($empresa->complemento); ?>">
                                                    <span class="fa fa-map-marker form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control cep has-feedback-left"
                                                        placeholder="CEP" name="cep" value="<?php echo e($empresa->cep); ?>">
                                                    <span class="fa fa-map-marker form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control telefone has-feedback-left"
                                                        placeholder="Celular" name="celular_rep"
                                                        value="<?php echo e($empresa->celular_rep); ?>">
                                                    <span class="fa fa-phone form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Nome do Contato" name="nome_contato"
                                                        value="<?php echo e($empresa->nome_contato); ?>">
                                                    <span class="fa fa-user form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Email Contato" name="email_contato"
                                                        value="<?php echo e($empresa->email_contato); ?>">
                                                    <span class="fa fa-at form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control telefone has-feedback-left"
                                                        placeholder="Celular Representante" name="celular_rep"
                                                        value="<?php echo e($empresa->celular_rep); ?>">
                                                    <span class="fa fa-phone form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <input type="text" class="form-control rg has-feedback-left"
                                                        placeholder="R.G. Representante" name="rg_rep"
                                                        value="<?php echo e($empresa->rg_rep); ?>">
                                                    <span class="fa fa-bars form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="step-2">
                                        <br>
                                        <div id="form-step-1" role="form" data-toggle="validator">
                                            <div class="row" style="width:960px; margin: 0 auto;">
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <label for="">Dia p/ Pgto Estágiario(a)</label>
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Dia p/ Pgto Estágiario(a)" name="data_estagiario"
                                                        value="<?php echo e($empresa->data_estagiario); ?>">
                                                    <span class="fa fa-calendar form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                      <label for="">Dia p/ Vcto Boleto</label>
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Dia p/ Vcto Boleto" name="data_boleto"
                                                        value="<?php echo e($empresa->data_boleto); ?>">
                                                    <span class="fa fa-calendar form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                            </div>
                                            <div class="row" style="width:960px; margin: 0 auto;">
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                     <label for="">Dia p/ Fechamento</label>
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Dia p/ Fechamento" name="data_fechamento"
                                                        value="<?php echo e($empresa->data_fechamento); ?>">
                                                    <span class="fa fa-calendar form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                            <div class="row" style="width:960px; margin: 0 auto;">
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <label for="">Custo unitário </label>
                                                    <input type="text" class="form-control has-feedback-left"
                                                        placeholder="Custo Unitário" name="custo_unitario"
                                                         value="<?php echo e($empresa->custo_unitario); ?>">
                                                    <span class="fa fa-money form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="row" style="width:500px; margin: 0 auto;">
                                                    <div class="col-md-12 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" class="flat" checked="checked">
                                                                Proporcional
                                                            </label>
                                                            <label>
                                                                <input type="checkbox" class="flat" checked="checked"> Está Ativo
                                                                <input type="hidden" value="1" name="ativo" />
                                                            </label>
                                                            <label>
                                                                <input type="checkbox" class="flat"> Dias Comerciais
                                                            </label>
                                                            <label>
                                                                <input type="checkbox" class="flat"> Roda Folha
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php echo Form::close(); ?>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->

<!-- footer content -->
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /footer content -->
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>