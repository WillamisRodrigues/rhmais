<?php $__env->startSection('titulo','TCE e Aditivos de Contratos Ativos - Gerar Avaliações Supervisor(a)'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->

        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <!-- <a href="<?php echo e(url('estagiario/exportar')); ?>">Print  PDF</a> -->
                <div class="clearfix"></div>

                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <a href="#" class="btn btn-success pull-right"> <i class="fa fa-print"> </i> Relátorio
                                    Avaliação Supervisores</a>
                                <h2>TCE e Aditivos de Contratos Ativos - Gerar Avaliações Supervisor(a)</h2>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <table class="table list table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Estagiario
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Unidade Concedente
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>TCE inicio/Fim</th>
                                            
                                            <th>Supervisor
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            
                                            <th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>SABRINA KELOLY VIEIRA DOS SANTOS</td>
                                            <td>LIFE ACADEMIA BRASIL EIRELI- EPP - ACADEMIA LIFE GYM</td>
                                            <td>10/09/2018 31/12/2019</td>
                                            
                                            <td>LUCIELENA NISTA</td>
                                            
                                            <td style="width:10%;">
                                                <div class="col-md-3">
                                                    <a href="<?php echo e(route('avaliacao_supervisor.create')); ?>"
                                                        class="btn btn-primary"> <i class="fa fa-pencil"> </i></a>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- /page content -->

    <!-- footer content -->
    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /footer content -->
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>