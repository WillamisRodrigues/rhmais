<?php $__env->startSection('titulo','Gerar Termo de Conclusão / Rescisão do TCE - Agente de integração (GTR-AI)'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- /menu profile quick info -->

                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- /sidebar menu -->
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="clearfix"></div>

            <div class="row">

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>Gerar Termo de Conclusão / Rescisão do TCE - Agente de integração (GTR-AI) </h2>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <form action="<?php echo e(route('tce_rescisao.store')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>


                                <!-- SmartWizard html -->
                                <div>
                                    <div>
                                        <div>
                                            <?php $__currentLoopData = $tceContrato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <div id="form-step-0" role="form" data-toggle="validator">
                                                <div class="row" style="width:960px; margin: 20px auto;">
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <input type="text" value="<?php echo e($tce->nome); ?>"
                                                            class="form-control has-feedback-left"
                                                            placeholder="Estágiario" name="nome">
                                                        <input type="hidden"  name="estagiario_id" value="<?php echo e($tce->estagiario_id); ?>">
                                                        <span class="fa fa-user form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <input type="text" value="<?php echo e($tce->nome_instituicao); ?>"
                                                            class="form-control has-feedback-left"
                                                            placeholder="Instituição de Ensino" name="nome_instituicao">
                                                            <input type="hidden"  name="instituicao_id" value="<?php echo e($tce->instituicao_id); ?>">
                                                        <span class="fa fa-home form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <input type="text" value="<?php echo e($tce->nome_fantasia); ?>"
                                                            class="form-control has-feedback-left"
                                                            placeholder="Unidade Concedente" name="nome_fantasia">
                                                            <input type="hidden"  name="empresa_id" value="<?php echo e($tce->empresa_id); ?>">
                                                        <span class="fa fa-home form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <input type="text" value="<?php echo e("R$ " .number_format($tce->bolsa, 2)); ?>"
                                                            class="form-control has-feedback-left"
                                                            placeholder="Valor Bolsa-Auxilio" name="bolsa">
                                                        <span class="fa fa-money form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                                                        <input type="text"
                                                            value="<?php echo e(date('d/m/Y', strtotime($tce->data_inicio))); ?>"
                                                            class="form-control has-feedback-left"
                                                            placeholder="Data TCE" name="data_tce">
                                                        <span class="fa fa-calendar form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                                                        <input type="text"
                                                            value="<?php echo e(date('d/m/Y', strtotime($tce->data_inicio))); ?>"
                                                            class="form-control has-feedback-left"
                                                            placeholder="Data Inicio" name="data_inicio">
                                                        <span class="fa fa-calendar form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                                                        <input type="text"
                                                            value="<?php echo e(date('d/m/Y', strtotime($tce->data_fim))); ?>"
                                                            class="form-control has-feedback-left"
                                                            placeholder="Data Fim" name="data_fim">
                                                        <span class="fa fa-calendar form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <input type="text" value="<?php echo e($tce->horario); ?>"
                                                            class="form-control has-feedback-left"
                                                            placeholder="Horário Estágio" name="horario">
                                                        <span class="fa fa-clock-o form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <input type="text" value="<?php echo e($tce->apolice); ?>"
                                                            class="form-control has-feedback-left"
                                                            placeholder="Apolice / Seguradora" name="apolice">
                                                        <span class="fa fa-bars form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label for="">Beneficio</label>
                                                        <textarea class="form-control" placeholder="Beneficio"
                                                            name="beneficio"></textarea>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label for="">Atividade / Setor </label>
                                                        <textarea class="form-control" placeholder="Atividade / Setor"
                                                            name="setor"></textarea>
                                                    </div>
                                                      <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <select class="form-control has-feedback-left" name="supervisor_id" value="<?php echo e($tce->supervisor_id); ?>">
                                                                    <?php $__currentLoopData = $supervisor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($tce->supervisor_id == $sup->id): ?>
                                                                       <option value="<?php echo e($sup->nome); ?>"><?php echo e($sup->nome); ?></option>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $__currentLoopData = $supervisor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($sup->id); ?>"><?php echo e($sup->nome); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                     </div>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <select class="form-control has-feedback-left" name="motivo">
                                                            <option>Selecione Motivo</option>
                                                              <?php $__currentLoopData = $motivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($motivo->nome); ?>"><?php echo e($motivo->nome); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <span class="fa fa-bars form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label for=""> Último Dia </label>
                                                        <input type="date" class="form-control has-feedback-left"
                                                            placeholder="Último Dia" name="ultimo_dia
                                                ">
                                                        <span class="fa fa-calendar form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label for=""> Data Documento </label>
                                                        <input type="date" class="form-control has-feedback-left"
                                                            placeholder="Data Documento" name="data_documento
                                                ">
                                                        <span class="fa fa-calendar form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
                                                        <label for="">Observação </label>
                                                        <textarea class="form-control" placeholder="Observação"
                                                            name="obs"></textarea>
                                                    </div>
                                                </div>
                                                <div class="btn-group mr-2 sw-btn-group-extra" role="group">
                                                    <button type="submit" class="btn btn-info">Enviar</button>
                                                    <button class="btn btn-danger">Cancelar</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /page content -->

    <!-- footer content -->
    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /footer content -->
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>