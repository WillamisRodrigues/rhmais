<?php $__env->startSection('titulo','Setores - Listagem | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <!-- <a href="<?php echo e(url('cidade/exportar')); ?>">Print  PDF</a> -->
                <div class="clearfix"></div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <?php echo $__env->make('layout.alerta.flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="x_panel">
                            <div class="x_title">
                                <a href=<?php echo e(route('setor.create')); ?> class="btn btn-success pull-right"> <i
                                        class="fa fa-list"> </i> Novo</a>
                                <h2>Setores - Listagem</h2>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <table class="table table-striped list table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Nome do Setor
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>Sigla do Setor
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <?php $__currentLoopData = $setores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($setor->nome); ?></td>
                                            <td><?php echo e($setor->sigla); ?></td>
                                            <td style="width:15%;">
                                                <div class="col-md-3">
                                                    <a href="<?php echo e(route('setor.edit', [$setor->id])); ?>"
                                                        class="btn btn-primary" title="Editar"> <i class="fa fa-pencil"> </i></a>
                                                </div>
                                                <form class="col-md-3" style="margin-left:10px;"
                                                    action="<?php echo e(url('setor', [$setor->id])); ?>" method="POST">
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                    <button type="submit" class="btn btn-danger" data-toggle="tooltip"
                                                        data-placement="top" title="Excluir"
                                                        onclick="return confirm('Tem certeza que deseja deletar o motivo selecionado?')">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                            </div>
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!-- /page content -->

<!-- footer content -->
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /footer content -->
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>