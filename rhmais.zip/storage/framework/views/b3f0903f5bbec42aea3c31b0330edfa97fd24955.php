<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>laravel 6 First Ajax CRUD Application - W3path.com</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

 <style>
   .container{
    padding: 0.5%;
   }
</style>
</head>
<div class="modal fade" id="ajax-crud-modal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title" id="userCrudModal"></h4>
        </div>
        <form id="userForm" name="userForm" class="form-horizontal">
          <div class="modal-body">
              <input type="hidden" name="estagiario_id" id="estagiario_id">
              <div class="form-group">
                <label for="name" class="col-sm-2 control-label">Referencia</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="referencia" name="referencia" placeholder="Referencia" value="" maxlength="50" required="">
                </div>
              </div>

              <div class="form-group">
              <label class="col-sm-2 control-label">Estagiario ID</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="estagiario_id" name="estagirario_id" placeholder="Estagiario ID" value="" required="">
                </div>
              </div>
          </div>
          <div class="modal-footer">
              <button type="submit" class="btn btn-primary" id="btn-save" value="create">
                Save changes
              </button>
          </div>
        </form>
    </div>
  </div>
</div>