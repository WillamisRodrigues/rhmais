<!-- footer content -->
<footer>
    <div class="pull-right">
        2019 - RH MAIS sistema de RH
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->
