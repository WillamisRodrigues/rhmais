<?php $__env->startSection('titulo','TCE e Aditivos de Contratos Ativos - Gerar Avaliações - TCE | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- /menu profile quick info -->

                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- /sidebar menu -->
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="clearfix"></div>

            <div class="row">

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>TCE e Aditivos de Contratos Ativos - Gerar Avaliações</h2>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <form action="<?php echo e(route('beneficio.store')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>


                                <!-- SmartWizard html -->
                                <div>
                                    <div>
                                        <div>
                                            <div style="width:960px; margin: 20px auto;">
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <select class="form-control has-feedback-left" name="estagiario_id">
                                                        <option>Selecione Estagiário:</option>
                                                        <?php $__currentLoopData = $estagiarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estagiario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($estagiario->id); ?>"><?php echo e($estagiario->nome); ?>

                                                        </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <span class="fa fa-user form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <select class="form-control has-feedback-left" name="instituicao_id">
                                                        <option>Instituição de ensino:</option>
                                                        <?php $__currentLoopData = $instituicoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instituicao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($instituicao->id); ?>">
                                                            <?php echo e($instituicao->nome_instituicao); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <span class="fa fa-home form-control-feedback left"
                                                        aria-hidden="true"></span>
                                                </div>
                                            </div>
                                        <div style="width:960px; margin: 20px auto;">
                                            <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                <select class="form-control has-feedback-left" name="empresa_id">
                                                    <option>Selecione Unidade Concedente:</option>
                                                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($empresa->id); ?>"><?php echo e($empresa->nome_fantasia); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <span class="fa fa-home form-control-feedback left"
                                                    aria-hidden="true"></span>
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                <select class="form-control has-feedback-left" name="supervisor_id">
                                                    <option>Supervisor:</option>
                                                    <?php $__currentLoopData = $supervisores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($supervisor->id); ?>"><?php echo e($supervisor->nome); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <span class="fa fa-home form-control-feedback left"
                                                    aria-hidden="true"></span>
                                            </div>
                                        </div>
                                            <div id="form-step-0" role="form" data-toggle="validator">
                                                <div class="row" style="width:960px; margin: 20px auto;">
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <input type="text" class="form-control has-feedback-left"
                                                            placeholder="Período Avaliativo: *"
                                                            name="periodo_avaliativo">
                                                        <span class="fa fa-calendar form-control-feedback left"
                                                            aria-hidden="true"></span>
                                                    </div>
                                                    <div id="form-step-0" role="form" data-toggle="validator">
                                                        <div class="row" style="width:960px; margin: 20px auto;">
                                                            <div
                                                                class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                                <input type="text"
                                                                    class="form-control has-feedback-left"
                                                                    placeholder="Data Documento:* " name="data_doc">
                                                                <span class="fa fa-calendar form-control-feedback left"
                                                                    aria-hidden="true"></span>
                                                            </div>
                                                            <div id="form-step-0" role="form" data-toggle="validator">
                                                                <div class="row"
                                                                    style="width:960px; margin: 20px auto;">
                                                                    <div
                                                                        class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
                                                                        <label for=""> observação: </label>
                                                                        <textarea
                                                                            class="form-control has-feedback-left"
                                                                            placeholder="Texto Obs.: " name="obs">
                                                                        </textarea>
                                                                        <div style="margin-top:20px;">
                                                                    
                                                                        <a  href="/avaliacao-pdf" target="_blank" class="btn btn-success">
                                                                        <i class="fa fa-print"></i>
                                                                        Gerar
                                                                        Avaliação</a>  
                                                                         <a href="/auto_avaliacao" class="btn btn-primary">Voltar</a>
                                                                    </div>
                                                                    </div>
                                                                </div>
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /page content -->
    <!-- footer content -->
    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /footer content -->
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>