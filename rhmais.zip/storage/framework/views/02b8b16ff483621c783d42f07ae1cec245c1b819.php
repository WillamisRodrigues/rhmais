<?php $__env->startSection('titulo','Termo Recesso Férias | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">

                <div class="clearfix"></div>

                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>TCE / Ad Ativo(s) - Gerar Termo de Recesso / Férias</h2>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <table class="table list table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Estagiário
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>Unidade Concedente
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>Valor da Bolsa
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>TCE Inicio / FIM</th>
                                            <th>Período <br> Aquisitivo</th>
                                            <th>Ferias Concedidas</th>
                                            <th style="min-width: 8rem">Valor Direito</th>
                                            <th style="min-width: 8rem">Valor Recebido</th>
                                            <th style="min-width: 8rem">Valor Saldo</th>
                                            <th>TCE / Ad Assinado <input type="text" class="form-control"
                                                    style="width:100px;"> </th>
                                            <th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $recessos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recesso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($recesso->nome); ?></td>
                                            <td><?php echo e($recesso->nome_fantasia); ?></td>
                                            <td><?php echo e("R$ " .number_format($recesso->bolsa, 2 )); ?></td>
                                            <td>
                                                <?php echo e(date('d/m/Y', strtotime($recesso->data_inicio))); ?><br>
                                                <?php echo e(date('d/m/Y', strtotime($recesso->data_fim))); ?><br>
                                            </td>
                                            <td>
                                                
                                                <?php echo e(App\Http\Controllers\RecessoController::periodoAquisitivo($recesso->tceId)); ?>

                                            </td>
                                            <td>
                                                <?php
                                                foreach($listaRecessos as $listaRecesso){
                                                if($recesso->id == $listaRecesso->estagiario_id){
                                                App\Http\Controllers\RecessoController::dias_Ferias($listaRecesso->data_inicio,
                                                $listaRecesso->data_fim);
                                                }
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                
                                                R$
                                                <?php echo e(App\Http\Controllers\RecessoController::valorFerias($recesso->data_inicio, $recesso->bolsa)); ?>

                                            </td>
                                            <td>
                                                <!-- 0,00 -->
                                                <?php
                                                foreach($listaRecessos as $listaRecesso){
                                                if($recesso->id == $listaRecesso->estagiario_id){
                                                echo "R$ ".$listaRecesso->vr_recebido;
                                                }
                                                }
                                                ?>

                                            </td>
                                            <td>
                                                <!-- 733,33 -->
                                                <!-- <?php echo e(App\Http\Controllers\RecessoController::valorSaldo($recesso->tceId)); ?> -->
                                                <?php
                                                foreach($listaRecessos as $listaRecesso){
                                                if($recesso->id == $listaRecesso->estagiario_id){
                                                echo "R$ ".$listaRecesso->vr_saldo;
                                                }
                                                }
                                                ?>
                                            </td>
                                            <td>Sim</td>
                                            <td><a href="<?php echo route('termo_recesso.edit', [$recesso->id]); ?>"
                                                    class="btn btn-primary" title="Lançar férias"> <i class="fa fa-plus"> </i>
                                                </a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /page content -->
    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>