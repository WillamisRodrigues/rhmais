<?php $__env->startSection('titulo','Estagiários do Sistema | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->

        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <!-- <a href="<?php echo e(url('estagiario/exportar')); ?>">Print  PDF</a> -->
                <div class="clearfix"></div>

                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <?php echo $__env->make('layout.alerta.flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="x_panel">
                            <div class="x_title">
                                <a href="<?php echo e(route('estagiario.create')); ?>" class="btn btn-success pull-right"> <i
                                        class="fa fa-user"> </i> Adicionar Novo Estagiário</a>
                                <h2>Estagiários</h2>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <table class="table list table-striped table-bordered" style="zoom:0.8;">
                                    <thead>
                                        <tr>
                                            <th>Nome
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>Unidade
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Tel.Celular
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>CPF
                                                <input type="text" class="form-control" style="width:200px;">
                                            </th>
                                            <th>Cidade
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Data de Nascimento
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Escolaridade
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Termino Curso
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Ativo
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Ação</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $estagiarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estagiario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($estagiario->nome); ?></td>
                                            <td><?php echo e($estagiario->nome_fantasia); ?></td>
                                            <td><?php echo e($estagiario->celular); ?></td>
                                            <td><?php echo e($estagiario->cpf); ?></td>
                                            <td><?php echo e($estagiario->cidade); ?></td>
                                            <td><?php echo e(date('d/m/Y', strtotime($estagiario->data_nascimento))); ?></td>
                                            <td>
                                               <?php echo e($estagiario->curso); ?>

                                            </td>
                                            <td><?php echo e(date('d/m/Y', strtotime($estagiario->termino_curso))); ?></td>
                                            <td>
                                                <?php if($estagiario->ativo == '1'): ?>
                                                Sim
                                                <?php else: ?>
                                                Não
                                                <?php endif; ?>
                                            </td>
                                            <td style="width:15%;">
                                                <div class="col-md-3">
                                                    <a href="<?php echo route('estagiario.edit', [$estagiario->id]); ?>"
                                                        class='btn btn-primary' title="Editar"><i class="fa fa-pencil"></i></a>
                                                </div>
                                                <form class="col-md-3" style="margin-left:20px;"
                                                    action="<?php echo e(route('estagiario.destroy', [$estagiario->id])); ?>"
                                                    method="POST">
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                    <button type="submit" class="btn btn-danger" title="Excluir" data-toggle="tooltip"
                                                        data-placement="top"
                                                        onclick="return confirm('Tem certeza que deseja deletar o estagiário selecionado?')">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /page content -->
    <!-- footer content -->
    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /footer content -->
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>