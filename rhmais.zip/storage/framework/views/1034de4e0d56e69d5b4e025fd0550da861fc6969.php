<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Holerite - Estagiario</title>

    <link rel="stylesheet" href="<?php echo e(public_path('/css/bootstrap.min.css')); ?>">
    <style>
        .page-break{
            display: block; page-break-after: always;
        }
        table,
        tr {
            border: 2px solid #999999;
        }

        body {
            font-size: 1.05rem
        }
    </style>
</head>

<body>
    <table class="table" style="max-width: 100%">
        <?php $__currentLoopData = $folhas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="2">Recibo de Pagamento Bolsa-Auxílio</td>
            <td>Referência</td>
            <td><?php echo e($data->referencia); ?></td>
        </tr>
        <tr>
            <td colspan="3">Agente de Integração: <br>KOSTER E KOSTER CONSULTORIA EM RH LTDA</td>
            <td>21.925.427/0001-70</td>
        </tr>
        <tr>
            <td colspan="3">Unidade Concedente: <br><?php echo e($data->nome_fantasia); ?></td>
            <td><?php echo e($data->cnpj); ?></td>
        </tr>
        <tr>
            <td colspan="2">Estagiário(a)<br> <?php echo e($data->nome); ?>  - <?php echo e($data->cpf); ?> </td>
            <td colspan="2">
                Data Início:  <?php echo e(date('d/m/Y', strtotime($data->data_inicio))); ?> <br>
                Data Fim:  <?php echo e(date('d/m/Y', strtotime($data->data_fim))); ?>

            </td>
        </tr>
        <tr>
            <td>Código</td>
            <td>Descrição</td>
            <td>Vencimentos</td>
            <td>Descontos</td>
        </tr>
        <tr>
            <td style="padding-left: 3rem">
                <?php echo "1"; ?><br>
                <?php if(isset($data->beneficio_id)): ?>
                      <?php echo "2"; ?>

                 <?php endif; ?>
               <br>
                <?php if(isset($data->beneficio_id)): ?>
                      <?php echo "3"; ?>

                 <?php endif; ?>
                <br>
            </td>
            <td>
                <?php echo "Bolsa Auxílio"; ?><br>
                 <?php if(isset($data->beneficio_id)): ?>
                     <?php echo "Beneficio"; ?><br>
                 <?php endif; ?>
                  <?php if(isset($data->beneficio_id)): ?>
                        <?php echo "Beneficio"; ?><br>
                 <?php endif; ?>
            </td>
            <td>
                 <?php if(isset($data->valor_bolsa)): ?>
                    <?php echo e("R$ " .number_format($data->valor_bolsa, 2)); ?>

                 <?php endif; ?>
                <br>
                
                 <?php if(isset($data->beneficio_id)): ?>
                     <?php echo e($data->valor_bolsa); ?>

                 <?php endif; ?>
                <?php if(isset($data->beneficio_id)): ?>
                     <?php echo e($data->valor_bolsa); ?>

                 <?php endif; ?>
                <br>
            </td>
            <td>
                
                <?php if(isset($data->beneficio_id)): ?>
                     <?php echo e($data->valor_bolsa); ?>

                 <?php endif; ?>
                <?php if(isset($data->beneficio_id)): ?>
                     <?php echo e($data->valor_bolsa); ?>

                 <?php endif; ?>
                <br>
            </td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td>Total de: <br><?php if(isset($data->valor_bolsa)): ?>
                    <?php echo e("R$ " .number_format($data->valor_bolsa, 2)); ?>

                    <?php else: ?>
                         <?php echo "000,00"; ?>

                 <?php endif; ?>
                </td>
            <td>Descontos: <br><?php if(isset($data->valor_desconto)): ?>
                <?php echo e($data->valor_desconto); ?>

            <?php endif; ?>  </td>
        </tr>
        <tr>
            <td colspan="3">Valor Base Bolsa-Auxílio <br><?php if(isset($data->valor_bolsa)): ?>
                    <?php echo e("R$ " .number_format($data->valor_bolsa, 2)); ?>

                    <?php else: ?>
                         <?php echo "000,00"; ?>

                 <?php endif; ?>
                </td>
            <td>Valor Líquido<br> <u><?php if(isset($data->valor_liquido)): ?>
                    <?php echo e("R$ " .number_format($data->valor_liquido, 2)); ?>

            <?php endif; ?>
        </u></td>
        </tr>
        <tr>
            <td colspan="2">Banco/Agência</td>
            <td colspan="2">Conta/Tipo</td>
        </tr>
        <tr>
            <td colspan="4">Mensagem: </td>
        </tr>
        
    </table>

    <div class="clearfix"></div>
    <div>
        <div style="float: left; margin-left: 3rem">
            ____/_____/_________<br>
            Data
        </div>
        <div style="float: left; margin-left: 12rem">
         <img src="<?php echo e(public_path('/images/logo-rhmais.png')); ?>" alt="" width="80">
        </div>
        <div style="float: right; margin-right: 3rem">
            ______________________________________<br>
            Assinatura
        </div>
    </div>
    <div class="clearfix"></div>

    <hr style="border: dotted 1px black">

    <table class="table" style="max-width: 100%">
        
        <tr>
            <td colspan="2">Recibo de Pagamento Bolsa-Auxílio</td>
            <td>Referência</td>
            <td><?php echo e($data->referencia); ?></td>
        </tr>
        <tr>
            <td colspan="3">Agente de Integração: <br>KOSTER E KOSTER CONSULTORIA EM RH LTDA</td>
            <td>21.925.427/0001-70</td>
        </tr>
         <tr>
            <td colspan="3">Unidade Concedente: <br><?php echo e($data->nome_fantasia); ?></td>
            <td><?php echo e($data->cnpj); ?></td>
        </tr>
        <tr>
            <td colspan="2">Estagiário(a)<br><?php echo e($data->nome); ?>  - <?php echo e($data->cpf); ?></td>
            <td colspan="2">
                Data Início: <?php echo e($data->data_inicio); ?><br>
                Data Fim: <?php echo e($data->data_fim); ?>

            </td>
        </tr>
        <tr>
            <td>Código</td>
            <td>Descrição</td>
            <td>Vencimentos</td>
            <td>Descontos</td>
        </tr>
        <tr>
            <td style="padding-left: 3rem">
                <?php echo "1"; ?><br>
                <?php if(isset($data->beneficio_id)): ?>
                      <?php echo "2"; ?>

                 <?php endif; ?>
               <br>
                <?php if(isset($data->beneficio_id)): ?>
                      <?php echo "3"; ?>

                 <?php endif; ?>
                <br>
            </td>
            <td>
              <?php echo "Bolsa Auxílio"; ?><br>
                 <?php if(isset($data->beneficio_id)): ?>
                     <?php echo "Beneficio"; ?><br>
                 <?php endif; ?>
                  <?php if(isset($data->beneficio_id)): ?>
                        <?php echo "Beneficio"; ?><br>
                 <?php endif; ?>
            </td>
            <td>
               <?php if(isset($data->valor_bolsa)): ?>
                    <?php echo e("R$ " .number_format($data->valor_bolsa, 2)); ?>

                 <?php endif; ?>
                <br>
                 <?php if(isset($data->beneficio_id)): ?>
                     <?php echo e($data->valor_bolsa); ?>

                 <?php endif; ?>
                <?php if(isset($data->beneficio_id)): ?>
                     <?php echo e($data->valor_bolsa); ?>

                 <?php endif; ?>
            <br>
            </td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td>Total de: <br><?php if(isset($data->valor_bolsa)): ?>
                    <?php echo e("R$ " .number_format($data->valor_bolsa, 2)); ?>

                    <?php else: ?>
                         <?php echo "000,00"; ?>

                 <?php endif; ?>
                </td>
            <td>Descontos: <br><?php if(isset($data->valor_desconto)): ?>
                <?php echo e($data->valor_desconto); ?>

            <?php endif; ?>  </td>
        </tr>
        <tr>
            <td colspan="3">Valor Base Bolsa-Auxílio <br><?php if(isset($data->valor_bolsa)): ?>
                    <?php echo e("R$ " .number_format($data->valor_bolsa, 2)); ?>

                    <?php else: ?>
                         <?php echo "000,00"; ?>

                 <?php endif; ?>
                </td>
            <td>Valor Líquido<br> <u><?php if(isset($data->valor_liquido)): ?>
                    <?php echo e("R$ " .number_format($data->valor_liquido, 2)); ?>

            <?php endif; ?>
            </u></td>
        </tr>
        <tr>
            <td colspan="2">Banco/Agência</td>
            <td colspan="2">Conta/Tipo</td>
        </tr>
        <tr>
            <td colspan="4">Mensagem: </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <div class="clearfix"></div>
    <div>
        <div style="float: left; margin-left: 3rem">
            ____/_____/_________<br>
            Data
        </div>
        <div style="float: left; margin-left: 12rem">
        
        <img src="<?php echo e(public_path('images/logo-rhmais.png')); ?>" alt="" width="80">
        </div>
        <div style="float: right; margin-right: 3rem">
            ______________________________________<br>
            Assinatura
        </div>
    </div>

</body>

</html>
