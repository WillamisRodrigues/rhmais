<?php $__env->startSection('titulo','RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form method="POST" action="<?php echo e(route('login')); ?>">
             <?php echo csrf_field(); ?>
              <h1>LOGIN RH MAIS</h1>
               <div>
                                <input placeholder="e-mail" id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
             <div>
                                <input placeholder="Senha"  id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div>
                                <button type="submit" class="btn btn-default submit">
                                    <?php echo e(__('Logar')); ?>

                                </button>

                                <?php if(Route::has('password.request')): ?>
                                   -<a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Esqueceu sua senha?')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                       <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">Novo no sistema?
                  <a href="<?php echo e(route('user-add')); ?>" class="to_register"> Criar Conta </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                  <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" style="width:100px;">
                  <p>©2019 RH MAIS Todos os direitos reservados</p>
                </div>
              </div>
            </form>
          </section>
        </div>

        <div id="register" class="animate form registration_form">
          <section class="login_content">
            <form class="form-horizontal form-label-left" novalidate action="<?php echo e(route('user-post')); ?>" method="post">
            <?php echo csrf_field(); ?>
              <h1>Criar Conta</h1>
              <div>
                <input type="text" class="form-control"  placeholder="Usuario" required="" />
                <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
              </div>
              <div>
                <input type="email" class="form-control" placeholder="Email" required="required" />
              </div>
              <div>
                <input type="password" class="form-control" placeholder="Password" required="" />
              </div>
              <div>
                <a class="btn btn-default submit" href="index.html">Criar</a>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">Já Possue Conta ?
                  <a href="#signin" class="to_register"> Entrar </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" style="width:100px;">
                  <p>©2019 RH MAIS Todos os direitos reservados</p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rhmais\resources\views/login/login.blade.php ENDPATH**/ ?>