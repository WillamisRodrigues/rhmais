<?php $__env->startSection('titulo','Lista das Auto-Avaliações Geradas | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->

        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <!-- <a href="<?php echo e(url('estagiario/exportar')); ?>">Print  PDF</a> -->
                <div class="clearfix"></div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <form action="">
                        <div class="col-md-4">
                            <br>
                            
                        </div>
                    </form>
                    <br>

                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Listar Estagiários</h2>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <?php echo Form::open(['route' => ['filtrar-estagiario'], 'method' => 'post']); ?>

                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                        <label for="">Supervisor</label>
                                        <select name="supervisor_id" class="form-control has-feedback-left" id="">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $supervisores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($supervisor->id); ?>"><?php echo e($supervisor->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                        <label for="">Empresa</label>
                                        <select name="empresa_id" class="form-control has-feedback-left" id="">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($empresa->id); ?>"><?php echo e($empresa->nome_fantasia); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-12 col-sm-12">
                                        <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i> Pesquisar</button>
                                    </div>
                                    <?php echo Form::close(); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- /page content -->

        <!-- footer content -->
        <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- /footer content -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>