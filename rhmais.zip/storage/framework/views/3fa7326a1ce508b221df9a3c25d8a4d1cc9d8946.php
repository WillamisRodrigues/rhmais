<?php $__env->startSection('titulo','Lista das Auto-Avaliações Geradas | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->

        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <!-- <a href="<?php echo e(url('estagiario/exportar')); ?>">Print  PDF</a> -->
                <div class="clearfix"></div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <form action="">
                        <div class="col-md-4">
                            <br>
                            
                        </div>
                    </form>
                    <br>

                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Lista das Auto-Avaliações Geradas</h2>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <table class="table list table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Estagiario
                                                    <input type="text" class="form-control">
                                                </th>
                                                <th style="width:10%:">Un. Concedente
                                                    <input type="text" class="form-control" style="width:100px;">
                                                </th>
                                                <th>Supervisor
                                                    <input type="text" class="form-control" style="width:100px;">
                                                </th>
                                                <th>Perido Avaliativo
                                                    <input type="text" class="form-control" style="width:100px;">
                                                </th>
                                                <th>Avaliação Branco Período
                                                    <input type="text" class="form-control" style="width:100px;">
                                                </th>
                                                <th>Situação</th>
                                                <th>Opções</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $avaliacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avaliacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php $__currentLoopData = $estagiarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estagiario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($estagiario->id == $avaliacao->estagiario_id): ?>
                                                    <?php echo e($estagiario->nome); ?>

                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td style="width:24%;">
                                                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($empresa->id == $avaliacao->empresa_id): ?>
                                                    <?php echo e($empresa->nome_fantasia); ?>

                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>
                                                    <?php $__currentLoopData = $orientadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orientador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($orientador->id == $avaliacao->supervisor): ?>
                                                    <?php echo e($orientador->nome); ?>

                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td><?php echo e(date('d/m/Y', strtotime($avaliacao->periodo_avaliativo))); ?></td>
                                                <td>10/09/2018 a 10/03/2019</td>
                                                <td>
                                                    <?php if($avaliacao->status != 1): ?>
                                                    Não Assinado
                                                    <?php else: ?>
                                                    Assinado
                                                    <?php endif; ?>
                                                </td>
                                                <td style="width:24%;">
                                                    <div class="col-md-3">
                                                        <a href="<?php echo e(route('assinar.avaliacao.estagiario', [$avaliacao->id])); ?>"
                                                            class="btn btn-primary">
                                                            <i class="fa fa-star" title="Marcar como assinado"> </i> </a>
                                                    </div>
                                                    <a href="/editar_avaliacao_estagiario" class="btn btn-primary">
                                                        <i class="fa fa-pencil" title="Editar"> </i> </a>
                                </div>
                                
                                
                                
                                
                                <a href="<?php echo e(route('deletar.avaliacao.estagiario', [$avaliacao->id])); ?>"
                                    class="btn btn-danger" title="Excluir">
                                    <i class="fa fa-trash"></i>
                                </a>
                                </button>
                                </form>
                                <div class="col-md-3">
                                    <a href="#" class="btn btn-warning" title="Imprimir"> <i class="fa fa-print"> </i> </a>
                                </div>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- /page content -->

    <!-- footer content -->
    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /footer content -->
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>