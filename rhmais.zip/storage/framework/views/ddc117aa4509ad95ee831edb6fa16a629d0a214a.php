<?php $__env->startSection('titulo','Lista de Contratos Ativos - TCE | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->

        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <!-- <a href="<?php echo e(url('tce/exportar')); ?>">Print  PDF</a> -->
                <div class="clearfix"></div>

                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <a href="<?php echo e(route('tce_contrato.create')); ?>" class="btn btn-success pull-right"> <i
                                        class="fa fa-plus"> </i> Adicionar Novo Contrato</a>
                                <h2>AGENTE DE INTEGRAÇÃO - Lista de Contratos Ativos - TCE</h2>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <table class="table list table-striped table-responsive w-auto table-bordered"
                                    style="zoom:0.8;">
                                    <thead>
                                        <tr>
                                            <th>Estagiario
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>Un. Concedente
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>Instituição
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>Valor Bolsa
                                                <input type="text" style="width:100px;" class="form-control">
                                            </th>
                                            <th>Data Inicio
                                                <input type="text" style="width:100px;" class="form-control">
                                            </th>
                                            <th>Data Fim
                                                <input type="text" style="width:100px;" class="form-control">
                                            </th>
                                            <th>Contrato
                                                <input type="text" style="width:100px;" class="form-control">
                                            </th>
                                            <th>Assinado
                                                <input type="text" style="width:100px;" class="form-control">
                                            </th>
                                            <th>Obrigatório
                                                <input type="text" style="width:100px;" class="form-control">
                                            </th>
                                            <th>Opções
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $tces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($tce->nome); ?></td>
                                            <td><?php echo e($tce->nome_fantasia); ?></td>
                                            <td><?php echo e($tce->nome_instituicao); ?></td>
                                            <td><?php echo e("R$ " .number_format($tce->bolsa, 2)); ?></td>
                                            <td><?php echo e(date('d/m/Y', strtotime($tce->data_inicio))); ?></td>
                                            <td><?php echo e(date('d/m/Y', strtotime($tce->data_fim ))); ?></td>
                                            <td><?php echo e($tce->contrato); ?></td>
                                            <td>
                                                <?php if($tce->assinado == '1'): ?>
                                                Sim
                                                <?php else: ?>
                                                Não
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                 <?php if( $tce->obrigatorio == '1'): ?>
                                                Sim
                                                <?php else: ?>
                                                Não
                                                <?php endif; ?>
                                            </td>
                                            <td style="width:22%;">
                                                <a href="<?php echo e(action('EstagiarioController@gerarRelatorio', $tce->id)); ?>"
                                                   class="btn btn-primary" title="Imprimir TCE"><i class="fa fa-print"></i></a>
                                                <a href="<?php echo e(route('tce_contrato.edit',[$tce->tceId])); ?>"
                                                    class="btn btn-danger" title="Gerar Rescisão"><i class="fa fa-pencil"></i> </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- /page content -->

    <!-- footer content -->
    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /footer content -->
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>