<?php $__env->startSection('titulo','Termo Recesso Férias | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
   <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <?php echo $__env->make('layout.menu.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <br />
            <?php echo $__env->make('layout.menu.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
            <?php echo $__env->make('layout.menu.menutop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- page content -->
          <!-- page content -->
          <div class="right_col" role="main">
          <div class="">

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>TCE / Ad Ativo(s) - Gerar Termo de Recesso / Férias</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <table id="recesso" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                          <th>Estagiário</th>
                          <th>Unidade Concedente</th>
                          <th>Valor da Bolsa</th>
                          <th>TCE Inicio / FIM</th>
                          <th>Período <br> Aquisitivo</th>
                          <th>Ferias Concedidas</th>
                          <th>Valor Direito</th>
                          <th>Valor Recebido</th>
                          <th>Valor Saldo</th>
                          <th>TCE / Ad Assinado </th>
                          <th>Opções</th>
                        </tr>
                      </thead>


                      <tbody>
                        <tr>
                          <td>Nathalie Kesley Viana Silva</td>
                          <td>Arymana Contabilidade Eireli</td>
                          <td>800,00</td>
                          <td>01/08/2018 <br> 01/08/2020</td>
                          <td>01/08/2018 <br>01/08/2019 <br>11/12 27.5 <br> Dias
                        02/08/2019 <br> 01/08/2020 <br> n/c
                          </td>
                          <td></td>
                          <td>733,33</td>
                          <td>0,00</td>
                          <td>733,33</td>
                          <td>Sim</td>
                          <td><a href="" class="btn btn-primary"> <i class="fa fa-plus"> </i> Adicionar</a></td>
                        </tr>
                        <tr>
                          <td>Nathalie Kesley Viana Silva</td>
                          <td>Arymana Contabilidade Eireli</td>
                          <td>800,00</td>
                          <td>01/08/2018 <br> 01/08/2020</td>
                          <td>01/08/2018 <br>01/08/2019 <br>11/12 27.5 <br> Dias
                        02/08/2019 <br> 01/08/2020 <br> n/c
                          </td>
                          <td></td>
                          <td>733,33</td>
                          <td>0,00</td>
                          <td>733,33</td>
                          <td>Sim</td>
                          <td><a href="" class="btn btn-primary"> <i class="fa fa-plus"> </i> Adicionar</a></td>
                        </tr>
                        <tr>
                          <td>Nathalie Kesley Viana Silva</td>
                          <td>Arymana Contabilidade Eireli</td>
                          <td>800,00</td>
                          <td>01/08/2018 <br> 01/08/2020</td>
                          <td>01/08/2018 <br>01/08/2019 <br>11/12 27.5 <br> Dias
                        02/08/2019 <br> 01/08/2020 <br> n/c
                          </td>
                          <td></td>
                          <td>733,33</td>
                          <td>0,00</td>
                          <td>733,33</td>
                          <td>Sim</td>
                          <td><a href="" class="btn btn-primary"> <i class="fa fa-plus"> </i> Adicionar</a></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
    </div>
        <!-- /page content -->
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rhmais\resources\views/termo/lista-recesso.blade.php ENDPATH**/ ?>