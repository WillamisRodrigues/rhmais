<?php $__env->startSection('titulo','Cadastro Usuário | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
          <?php echo $__env->make('layout.menu.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /menu profile quick info -->

            <br />
            <?php echo $__env->make('layout.menu.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /sidebar menu -->
          </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="clearfix"></div>

            <div class="row">

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Editar Dados do Usuário</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                     <form action="<?php echo e(route('usuario.update',$usuario->id)); ?>" id="myForm" role="form" data-toggle="validator" method="post" accept-charset="utf-8">
            <input type="hidden" name="_method" value="PUT">
                  <?php echo e(csrf_field()); ?>

                      <!-- SmartWizard html -->
                      <div id="smartwizard">
                          <ul>
                              <li><a href="#step-1">Editar<br /><small>Dados Pessoais</small></a></li>
                          </ul>

                          <div>
                              <div id="step-1">
                                    <br>
                                  <div id="form-step-0" role="form" data-toggle="validator">
                                  <div class="row" style="width:960px; margin: 0 auto;">
                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                        <input type="text" value="<?php echo e($usuario->nome); ?>" class="form-control has-feedback-left" id="inputSuccess2" placeholder="Nome Completo" name="nome">
                                        <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                                    </div>

                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                        <input type="text"  value="<?php echo e($usuario->email); ?>" class="form-control" id="inputSuccess3" placeholder="Email" name="email">
                                        <span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
                                    </div>
                                    </div>
                                    <div class="row" style="width:960px; margin: 0 auto;">
                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                        <input type="text"   value="<?php echo e($usuario->rg); ?>" maxlength="12" class="form-control has-feedback-left" id="inputSuccess4" placeholder="RG" name="rg">
                                        <span class="fa fa-newspaper-o form-control-feedback left" aria-hidden="true"></span>
                                    </div>

                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                        <input type="text"  value="<?php echo e($usuario->cpf); ?>" maxlength="14" class="form-control" id="inputSuccess5" placeholder="CPF" name="cpf">
                                        <span class="fa fa-newspaper-o form-control-feedback right" aria-hidden="true"></span>
                                    </div>
                                    </div>
                                    <div class="row" style="width:960px; margin: 0 auto;">
                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                        <input type="text"  value="<?php echo e($usuario->telefone); ?>" class="form-control has-feedback-left" id="inputSuccess4" placeholder="Telefone" name="telefone">
                                        <span class="fa fa-phone form-control-feedback left" aria-hidden="true"></span>
                                    </div>

                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                        <input type="text"  value="<?php echo e($usuario->celular); ?>" class="form-control" id="inputSuccess5" placeholder="Celular" name="celular">
                                        <span class="fa fa-phone form-control-feedback right" aria-hidden="true"></span>
                                    </div>
                                    </div>
                                    <div class="row" style="width:960px; margin: 0 auto;">
                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                        <input type="date"   value="<?php echo e($usuario->data_nascimento); ?>" class="form-control has-feedback-left" id="inputSuccess4" placeholder="Data de Nascimento" name="data_nascimento">
                                        <span class="fa fa-calendar form-control-feedback left" aria-hidden="true"></span>
                                    </div>
                                    </div>
                                  </div>

                              </div>
                          </div>
                      </div>
                     </div>
                   <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
                      </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /footer content -->
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rhmais\resources\views/usuario/edit.blade.php ENDPATH**/ ?>