<?php $__env->startSection('titulo','Gerar Termo de Recesso/Férias | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">

                <div class="clearfix"></div>

                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Gerar Termo de Recesso/Férias</h2>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">

                                <div class="row">
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <strong>Estagiário:</strong> <?php echo $estagiario->nome; ?>

                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <strong>Instituição de Ensino:</strong> <?php echo $instituicao->nome_instituicao; ?>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <strong>Unidade Concedente:</strong>
                                        <?php echo $empresa->nome_fantasia; ?>

                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <strong>Valor Bolsa-Auxílio:</strong>
                                        <?php echo $contrato->bolsa; ?>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <strong>Data Início TCE:</strong>
                                        <?php echo date('d/m/Y', strtotime($contrato->data_doc)); ?>

                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <strong>Data de Início:</strong>
                                        <?php echo date('d/m/Y', strtotime( $contrato->data_inicio)); ?>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <strong>Data Fim:</strong>
                                        <?php echo date('d/m/Y', strtotime($contrato->data_fim)); ?>

                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <strong>Benefício:</strong>
                                        <?php $__currentLoopData = $beneficios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $contrato->beneficio_id   == $beneficio->id): ?>
                                            <?php echo e($beneficio->nome); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <strong>Apólice/Seguradora:</strong>
                                        <?php $__currentLoopData = $apolices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apolice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $contrato->apolice_id  == $apolice->id): ?>
                                            <?php echo e($apolice->nome); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <strong>Horário Estágio:</strong>
                                         <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(  $contrato->horario_id   == $horario->id): ?>
                                            <?php echo e($horario->descricao); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <strong>Atividade/Setor:</strong>
                                         <?php $__currentLoopData = $setores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $contrato->setor_id  == $setor->id): ?>
                                            <?php echo e($setor->nome); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <strong>Supervisor Estágio:</strong>
                                        <?php echo $supervisor->nome; ?>

                                    </div>
                                </div>
                                <hr>
                                <?php echo Form::open(['route' => 'termo_recesso.store']); ?>

                                <input type="hidden" name="estagiario_id" value="<?php echo $estagiario->id; ?>">
                                <input type="hidden" name="empresa_id" value="<?php echo $empresa->id; ?>">
                                <input type="hidden" name="bolsa" value="<?php echo $contrato->bolsa; ?>">
                                <input type="hidden" name="contrato_inicio" value="<?php echo $contrato->data_inicio; ?>">
                                <input type="hidden" name="contrato_fim" value="<?php echo $contrato->data_fim; ?>">
                                <input type="hidden" name="contrato_id" value="<?php echo $contrato->id; ?>">
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                        <select class="form-control has-feedback-left" name="motivo_id">
                                            <option>Selecione o Motivo:</option>
                                            <?php $__currentLoopData = $motivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo $motivo->id; ?>"><?php echo $motivo->nome; ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="fa fa-align-justify form-control-feedback left"
                                            aria-hidden="true"></span>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                        <input required type="text" class="form-control has-feedback-left"
                                            placeholder="Observação" name="observacao">
                                        <span class="fa fa-align-justify form-control-feedback left"
                                            aria-hidden="true"></span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4 col-sm-6 col-xs-12 form-group has-feedback">
                                        <label for="">Início do Recesso</label>
                                        <input required type="text" class="form-control has-feedback-left data"
                                            name="inicio_recesso">
                                        <span class="fa fa-calendar form-control-feedback left"
                                            aria-hidden="true"></span>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-xs-12 form-group has-feedback">
                                        <label for="">Fim do Recesso</label>
                                        <input required type="text" class="form-control has-feedback-left data"
                                            name="fim_recesso">
                                        <span class="fa fa-calendar form-control-feedback left"
                                            aria-hidden="true"></span>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-xs-12 form-group has-feedback">
                                        <label for="">Data do Documento</label>
                                        <input required type="text" class="form-control has-feedback-left data"
                                            name="data_doc">
                                        <span class="fa fa-calendar form-control-feedback left"
                                            aria-hidden="true"></span>
                                    </div>
                                </div>
                                <div class="btn-group mr-2 sw-btn-group-extra" role="group">
                                    <button type="submit" class="btn btn-info">Enviar</button>
                                    <a href="/termo_recesso" class="btn btn-danger">Cancelar</a>
                                </div>
                                <?php echo Form::close(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>