  <div class="container">
	<h1 class="mt-2">Pesquisa usuarios</h1>
        <?php if(count($usuarios) == 0): ?>
            <div class="alert alert-danger mt-2">Nenhum usuario encontrado!</div>
        <?php else: ?>
		<table class="table mt-2 text-center">
                <tr>
			<th>Id</th>
			<th class="text-left">Informação</th>
			<th>Nome</th>
			<th>Total</th>
			<th>Data</th>
                </tr>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>{ { $p->id } }</td>
                        <td class="text-left"{ { $p->informacao } }</td>
                        <td>{ { $p->nome } }</td>
                        <td>{ { $p->toal } }</td>
                        <td>{ { $p->data} }</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
    </div><?php /**PATH C:\xampp\htdocs\rhmais\resources\views/pesquisar.blade.php ENDPATH**/ ?>