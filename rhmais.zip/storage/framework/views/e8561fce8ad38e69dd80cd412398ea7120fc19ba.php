<?php $__env->startSection('titulo','Lista Termo de Recesso/Férias | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- page content -->
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">

                <div class="clearfix"></div>

                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Lista Termo de Recesso/Férias - (LTR)</h2>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <table class="table table-striped  list table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Estagiário
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>Unidade Concedente
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>Data Inicio
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Data Fim
                                                <input type="text" class="form-control" style="width:100px;">
                                            </th>
                                            <th>Situacao Termo Férias/Recesso</th>
                                            <th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $recesso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        <td><?php echo e($rec->nome); ?></td>
                                            <td><?php echo e($rec->nome_fantasia); ?></td>
                                            <td><?php echo e(date('d/m/Y', strtotime($rec->data_inicio))); ?></td>
                                            <td><?php echo e(date('d/m/Y', strtotime($rec->data_fim))); ?></td>
                                            <td>
                                                <?php if($rec->recesso_assinado == 1 ): ?>
                                                    Assinado
                                                 <?php else: ?>
                                                    Não Assinado
                                                <?php endif; ?>
                                                </td>
                                            <td>
                                                
                                                <a href="<?php echo e(route('recesso_assinado.assinar', [$rec->id])); ?>"
                                                    class="btn btn-primary" title="Marcar contrato como assinado"> <i
                                                        class="fa fa-star"></i> </a>
                                                <a href="#" class="btn btn-warning" title="Imprimir"> <i class="fa fa-print"> </i></a>
                                                
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /page content -->
    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>