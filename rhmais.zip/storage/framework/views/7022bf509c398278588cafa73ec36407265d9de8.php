<?php $__env->startSection('conteudo'); ?>

    <div>
      <a class="hiddenanchor" id="signup"></a>
      <!-- <a class="hiddenanchor" id="signin"></a> -->

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
              <form method="POST" action="<?php echo e(route('salvar')); ?>" enctype="multipart/form-data">
             <?php echo e(csrf_field()); ?>

              <h1>Criar Conta</h1>
              <div>
                <input id="name" type="text" class="form-control "  placeholder="Usuario" required="" name="name"/>
                <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
              </div>
              <div>
                <input id="email" type="email" class="form-control" placeholder="Email" required="required" name="email"/>
                                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
              </div>
              <div>
                <input id="password" type="password" class="form-control" placeholder="Senha" required="" name="password"/>
                <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
              </div>
               <label class="control-label col-md-3 col-sm-3 col-xs-12" for="password_confirmation">
                            </label>
              <input  type="password" class="form-control" placeholder="Confirmação de senha" required=""  name="password_confirmation"/>
              <div>
               <button class="btn btn-default">Criar</button>
                 <!-- <a  id="send" type="submit" class="btn btn-default submit" href="index.html">Criar</a> -->
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <div class="clearfix"></div>
                <br />

                <div>
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" style="width:100px;">
                  <p>©2019 RH MAIS Todos os direitos reservados</p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rhmais\resources\views/user-add.blade.php ENDPATH**/ ?>