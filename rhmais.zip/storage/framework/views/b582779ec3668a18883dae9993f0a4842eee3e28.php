<?php $__env->startSection('titulo','Usuários do Sistema | RH MAIS'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layout.menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br />
                <?php echo $__env->make('layout.menu.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('layout.menu.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- page content -->

        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">

                <div class="clearfix"></div>

                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                <a href="<?php echo e(route('user_sistema.create')); ?>" class="btn btn-success pull-right"> <i
                                        class="fa fa-user"> </i> Adicionar Novo Usuário</a>
                                <h2>Usuários do Sistema</h2>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <table class="table list table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Nome
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>E-mail
                                                <input type="text" class="form-control">
                                            </th>
                                            <th>Data de cadastro</th>
                                            <th>Ultima atualização</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($user->name); ?></th>
                                            <th><?php echo e($user->email); ?></th>
                                            <th><?php echo e(date('d/m/Y', strtotime($user->created_at))); ?></th>
                                            <th><?php echo e(date('d/m/Y', strtotime($user->updated_at))); ?></th>

                                            <td style="width:15%;">
                                                <div class="col-md-3">
                                                    <a href="<?php echo e(route('user_sistema.edit',$user->id)); ?>"
                                                        class="btn btn-primary" title="Editar"> <i class="fa fa-pencil"> </i></a>
                                                </div>
                                                <form class="col-md-3" style="margin-left:10px;"
                                                    action="<?php echo e(url('user_sistema', [$user->id])); ?>" method="POST">
                                                    <input type="hidden" name="_id" value="<?php echo $user->id; ?>">
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                    <button type="submit" class="btn btn-danger" title="Excluir"
                                                        onclick="return confirm('Tem certeza que deseja deletar o usuário do sistema?')">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- /page content -->

    <!-- footer content -->
    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /footer content -->
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>