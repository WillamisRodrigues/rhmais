<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DashboardViewModel extends Model
{
      protected $fillable = ['estagiario'];
}
