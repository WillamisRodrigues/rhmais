<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AvaliacaoSuper extends Model
{
    protected $fillable = ['id'];
    protected $table = 'avaliacao_super';
}
